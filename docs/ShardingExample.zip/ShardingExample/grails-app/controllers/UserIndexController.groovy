class UserIndexController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]

    // Poor man's login
    def login = {
    	session.userName = params.userName
    	render "User logged in."
    }

    // Poor man's logout    
    def logout = {
        session.userName = null
        render "User logged out"
    }

    def index = {
        redirect(action: "list", params: params)
    }

    def list = {
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [userIndexInstanceList: UserIndex.list(params), userIndexInstanceTotal: UserIndex.count()]
    }

    def create = {
        def userIndexInstance = new UserIndex()
        userIndexInstance.properties = params
        return [userIndexInstance: userIndexInstance]
    }

    def save = {
        def userIndexInstance = new UserIndex(params)
        if (userIndexInstance.save(flush: true)) {
            flash.message = "${message(code: 'default.created.message', args: [message(code: 'userIndex.label', default: 'UserIndex'), userIndexInstance.id])}"
            redirect(action: "show", id: userIndexInstance.id)
        }
        else {
            render(view: "create", model: [userIndexInstance: userIndexInstance])
        }
    }

    def show = {
        def userIndexInstance = UserIndex.get(params.id)
        if (!userIndexInstance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'userIndex.label', default: 'UserIndex'), params.id])}"
            redirect(action: "list")
        }
        else {
            [userIndexInstance: userIndexInstance]
        }
    }

    def edit = {
        def userIndexInstance = UserIndex.get(params.id)
        if (!userIndexInstance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'userIndex.label', default: 'UserIndex'), params.id])}"
            redirect(action: "list")
        }
        else {
            return [userIndexInstance: userIndexInstance]
        }
    }

    def update = {
        def userIndexInstance = UserIndex.get(params.id)
        if (userIndexInstance) {
            if (params.version) {
                def version = params.version.toLong()
                if (userIndexInstance.version > version) {
                    
                    userIndexInstance.errors.rejectValue("version", "default.optimistic.locking.failure", [message(code: 'userIndex.label', default: 'UserIndex')] as Object[], "Another user has updated this UserIndex while you were editing")
                    render(view: "edit", model: [userIndexInstance: userIndexInstance])
                    return
                }
            }
            userIndexInstance.properties = params
            if (!userIndexInstance.hasErrors() && userIndexInstance.save(flush: true)) {
                flash.message = "${message(code: 'default.updated.message', args: [message(code: 'userIndex.label', default: 'UserIndex'), userIndexInstance.id])}"
                redirect(action: "show", id: userIndexInstance.id)
            }
            else {
                render(view: "edit", model: [userIndexInstance: userIndexInstance])
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'userIndex.label', default: 'UserIndex'), params.id])}"
            redirect(action: "list")
        }
    }

    def delete = {
        def userIndexInstance = UserIndex.get(params.id)
        if (userIndexInstance) {
            try {
                userIndexInstance.delete(flush: true)
                flash.message = "${message(code: 'default.deleted.message', args: [message(code: 'userIndex.label', default: 'UserIndex'), params.id])}"
                redirect(action: "list")
            }
            catch (org.springframework.dao.DataIntegrityViolationException e) {
                flash.message = "${message(code: 'default.not.deleted.message', args: [message(code: 'userIndex.label', default: 'UserIndex'), params.id])}"
                redirect(action: "show", id: params.id)
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'userIndex.label', default: 'UserIndex'), params.id])}"
            redirect(action: "list")
        }
    }
}
