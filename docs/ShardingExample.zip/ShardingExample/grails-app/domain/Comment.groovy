class Comment {

    Integer userIndexId
    
    String comment

    static constraints = {
    }
}
