class UserIndex {

    String userName
    
    String shard
    
    static constraints = {
    }
}
