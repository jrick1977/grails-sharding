package com.jeffrick.grails.plugin.sharding

/**
 * Created by IntelliJ IDEA.
 * User: Jeff
 * Date: Jun 16, 2010
 * Time: 9:12:27 PM
 * To change this template use File | Settings | File Templates.
 */
class Shards {
  static shards = []

  static list() {
    return shards
  }

 
}
